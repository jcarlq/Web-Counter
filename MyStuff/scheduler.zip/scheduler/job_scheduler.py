from __future__ import annotations

import heapq
from collections import defaultdict
from typing import Any


class JobScheduler:
    def __init__(self, max_jobs_per_user: int):
        self.max_jobs_per_user = max_jobs_per_user
        self._jobs: dict[str, dict[str, Any]] = {}
        self._active_heap: list[tuple[int, int, str]] = []
        self._active_per_user: dict[str, int] = defaultdict(int)
        self._active_jobs = 0
        self._processed_jobs = 0
        self._cancelled_jobs = 0

    def add_job(
        self,
        job_id: str,
        user_id: str,
        priority: int,
        created_at: int,
        payload: dict,
    ) -> bool:
        if job_id in self._jobs:
            return False

        if self._active_per_user.get(user_id, 0) >= self.max_jobs_per_user:
            return False

        job = {
            "job_id": job_id,
            "user_id": user_id,
            "priority": priority,
            "created_at": created_at,
            "payload": payload,
            "status": "active",
        }

        self._jobs[job_id] = job
        self._active_per_user[user_id] += 1
        self._active_jobs += 1
        heapq.heappush(self._active_heap, (-priority, created_at, job_id))
        return True

    def cancel_job(self, job_id: str) -> bool:
        job = self._jobs.get(job_id)
        if job is None or job["status"] != "active":
            return False

        job["status"] = "cancelled"
        user_id = job["user_id"]
        self._active_per_user[user_id] -= 1
        if self._active_per_user[user_id] == 0:
            del self._active_per_user[user_id]

        self._active_jobs -= 1
        self._cancelled_jobs += 1

        self._active_heap.remove((-job["priority"], job["created_at"], job_id))
        heapq.heapify(self._active_heap)

        return True

    def get_next_job(self) -> dict | None:
        while self._active_heap:
            _neg_priority, _created_at, job_id = heapq.heappop(self._active_heap)
            job = self._jobs[job_id]

            job["status"] = "processed"
            user_id = job["user_id"]
            self._active_per_user[user_id] -= 1
            if self._active_per_user[user_id] == 0:
                del self._active_per_user[user_id]

            self._active_jobs -= 1
            self._processed_jobs += 1

            return {
                "job_id": job["job_id"],
                "user_id": job["user_id"],
                "priority": job["priority"],
                "created_at": job["created_at"],
                "payload": job["payload"],
            }

        return None

    def get_stats(self) -> dict:
        return {
            "active_jobs": self._active_jobs,
            "processed_jobs": self._processed_jobs,
            "cancelled_jobs": self._cancelled_jobs,
            "users_with_active_jobs": len(self._active_per_user),
        }
