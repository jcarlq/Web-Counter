import unittest

from job_scheduler import JobScheduler


class JobSchedulerTests(unittest.TestCase):
    def test_add_job_rejects_duplicate_id(self):
        scheduler = JobScheduler(max_jobs_per_user=2)

        self.assertTrue(scheduler.add_job("j1", "u1", 5, 10, {"k": 1}))
        self.assertFalse(scheduler.add_job("j1", "u2", 9, 1, {"k": 2}))

    def test_add_job_enforces_per_user_active_limit(self):
        scheduler = JobScheduler(max_jobs_per_user=1)

        self.assertTrue(scheduler.add_job("j1", "u1", 5, 10, {}))
        self.assertFalse(scheduler.add_job("j2", "u1", 6, 11, {}))

        processed = scheduler.get_next_job()
        self.assertIsNotNone(processed)
        self.assertEqual(processed["job_id"], "j1")

        self.assertTrue(scheduler.add_job("j2", "u1", 6, 11, {}))

    def test_get_next_job_ordering(self):
        scheduler = JobScheduler(max_jobs_per_user=10)

        # Priority wins first.
        self.assertTrue(scheduler.add_job("c", "u1", 5, 100, {}))
        self.assertTrue(scheduler.add_job("b", "u1", 10, 200, {}))
        self.assertTrue(scheduler.add_job("a", "u1", 10, 100, {}))
        self.assertTrue(scheduler.add_job("d", "u1", 10, 100, {}))

        # Expected order: a (p10,t100), d (p10,t100), b (p10,t200), c (p5,t100)
        self.assertEqual(scheduler.get_next_job()["job_id"], "a")
        self.assertEqual(scheduler.get_next_job()["job_id"], "d")
        self.assertEqual(scheduler.get_next_job()["job_id"], "b")
        self.assertEqual(scheduler.get_next_job()["job_id"], "c")
        self.assertIsNone(scheduler.get_next_job())

    def test_cancel_job_semantics(self):
        scheduler = JobScheduler(max_jobs_per_user=2)

        self.assertFalse(scheduler.cancel_job("missing"))
        self.assertTrue(scheduler.add_job("j1", "u1", 1, 1, {}))
        self.assertTrue(scheduler.cancel_job("j1"))
        self.assertFalse(scheduler.cancel_job("j1"))

        self.assertTrue(scheduler.add_job("j2", "u1", 2, 2, {}))
        self.assertEqual(scheduler.get_next_job()["job_id"], "j2")
        self.assertFalse(scheduler.cancel_job("j2"))

    def test_get_next_job_marks_processed_and_updates_stats(self):
        scheduler = JobScheduler(max_jobs_per_user=5)

        self.assertTrue(scheduler.add_job("j1", "u1", 1, 10, {"x": 1}))
        self.assertTrue(scheduler.add_job("j2", "u2", 2, 20, {"x": 2}))
        self.assertTrue(scheduler.cancel_job("j1"))

        next_job = scheduler.get_next_job()
        self.assertEqual(next_job, {
            "job_id": "j2",
            "user_id": "u2",
            "priority": 2,
            "created_at": 20,
            "payload": {"x": 2},
        })

        self.assertIsNone(scheduler.get_next_job())

        self.assertEqual(
            scheduler.get_stats(),
            {
                "active_jobs": 0,
                "processed_jobs": 1,
                "cancelled_jobs": 1,
                "users_with_active_jobs": 0,
            },
        )

    def test_max_jobs_per_user_zero_rejects_all_new_jobs(self):
        scheduler = JobScheduler(max_jobs_per_user=0)

        self.assertFalse(scheduler.add_job("j1", "u1", 1, 1, {}))
        self.assertFalse(scheduler.add_job("j2", "u2", 10, 2, {}))
        self.assertIsNone(scheduler.get_next_job())
        self.assertEqual(
            scheduler.get_stats(),
            {
                "active_jobs": 0,
                "processed_jobs": 0,
                "cancelled_jobs": 0,
                "users_with_active_jobs": 0,
            },
        )

    def test_users_with_active_jobs_tracks_unique_active_users(self):
        scheduler = JobScheduler(max_jobs_per_user=3)

        self.assertTrue(scheduler.add_job("j1", "u1", 5, 10, {}))
        self.assertTrue(scheduler.add_job("j2", "u1", 4, 11, {}))
        self.assertTrue(scheduler.add_job("j3", "u2", 3, 12, {}))
        self.assertEqual(scheduler.get_stats()["users_with_active_jobs"], 2)

        self.assertTrue(scheduler.cancel_job("j3"))
        self.assertEqual(scheduler.get_stats()["users_with_active_jobs"], 1)

        self.assertIsNotNone(scheduler.get_next_job())
        self.assertEqual(scheduler.get_stats()["users_with_active_jobs"], 1)

        self.assertIsNotNone(scheduler.get_next_job())
        self.assertEqual(scheduler.get_stats()["users_with_active_jobs"], 0)

    def test_job_id_is_never_reusable_after_processed_or_cancelled(self):
        scheduler = JobScheduler(max_jobs_per_user=2)

        self.assertTrue(scheduler.add_job("same", "u1", 10, 1, {}))
        self.assertIsNotNone(scheduler.get_next_job())
        self.assertFalse(scheduler.add_job("same", "u2", 1, 2, {}))

        self.assertTrue(scheduler.add_job("other", "u1", 5, 3, {}))
        self.assertTrue(scheduler.cancel_job("other"))
        self.assertFalse(scheduler.add_job("other", "u3", 7, 4, {}))

    def test_cancelled_jobs_are_eagerly_removed_from_heap(self):
        scheduler = JobScheduler(max_jobs_per_user=5)

        self.assertTrue(scheduler.add_job("j1", "u1", 100, 1, {}))
        self.assertTrue(scheduler.add_job("j2", "u2", 50, 2, {}))
        self.assertTrue(scheduler.add_job("j3", "u3", 10, 3, {}))
        self.assertEqual(len(scheduler._active_heap), 3)

        self.assertTrue(scheduler.cancel_job("j1"))
        self.assertEqual(len(scheduler._active_heap), 2)

        self.assertTrue(scheduler.cancel_job("j2"))
        self.assertEqual(len(scheduler._active_heap), 1)

        next_job = scheduler.get_next_job()
        self.assertIsNotNone(next_job)
        self.assertEqual(next_job["job_id"], "j3")
        self.assertEqual(len(scheduler._active_heap), 0)
        self.assertIsNone(scheduler.get_next_job())

    def test_stress_mixed_workload_order_and_stats(self):
        scheduler = JobScheduler(max_jobs_per_user=3)

        jobs = [
            ("a1", "u1", 5, 10),
            ("a2", "u1", 9, 30),
            ("a3", "u1", 9, 20),
            ("b1", "u2", 9, 20),
            ("b2", "u2", 7, 15),
            ("b3", "u2", 7, 15),
            ("c1", "u3", 10, 5),
            ("c2", "u3", 5, 10),
            ("d1", "u4", 1, 1),
            ("e1", "u5", 9, 20),
        ]

        for job_id, user_id, priority, created_at in jobs:
            self.assertTrue(
                scheduler.add_job(
                    job_id,
                    user_id,
                    priority,
                    created_at,
                    {"source": user_id},
                )
            )

        # User u1 is at capacity and cannot add another active job.
        self.assertFalse(scheduler.add_job("a4", "u1", 100, 0, {}))

        # Cancel jobs that would otherwise appear early and late in ordering.
        self.assertTrue(scheduler.cancel_job("b1"))
        self.assertTrue(scheduler.cancel_job("d1"))
        self.assertFalse(scheduler.cancel_job("d1"))

        processed_ids = []
        while True:
            job = scheduler.get_next_job()
            if job is None:
                break
            processed_ids.append(job["job_id"])

        self.assertEqual(
            processed_ids,
            ["c1", "a3", "e1", "a2", "b2", "b3", "a1", "c2"],
        )

        self.assertEqual(
            scheduler.get_stats(),
            {
                "active_jobs": 0,
                "processed_jobs": 8,
                "cancelled_jobs": 2,
                "users_with_active_jobs": 0,
            },
        )


if __name__ == "__main__":
    unittest.main()
